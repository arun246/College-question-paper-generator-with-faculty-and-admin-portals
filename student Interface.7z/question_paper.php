<?php
ini_set("display_errors","1");
echo $_SERVER["DOCUMENT_ROOT"];
 echo $_SERVER['PHP_SELF']; 

echo"<h1>hello</h1>";

?>
<html>
    <head>
        <title> paper gener
        </title>
    </head>
    <body>
        <form method = "POST" action = "<?php echo $_SERVER['PHP_SELF']; ?>">
        Select some desserts:
        <select name = "dessert[]" multiple = "multiple">
        <option value = "iceCream"> Vanilla Ice Cream </option>
        <option value = "pie"> Apple Pie </option>
        <option value = "cake"> Chocolate Cake </option>
        <option value = "custard"> Creme Brulee </option>
        <option value = "jello"> Jello </option>
        </select>
        <input type = "submit" name = "Order">
        </form>
    </body>
</html>