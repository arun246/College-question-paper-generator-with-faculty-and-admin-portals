<?php
session_start();

$username = "";
$errors = array(); 

$db = mysqli_connect('localhost', 'root', '', 'registration');


if (isset($_POST['reg_user'])) {
  
  $username = mysqli_real_escape_string($db, $_POST['username']);
  $password_1 = mysqli_real_escape_string($db, $_POST['password_1']);

  if (empty($username)) { array_push($errors, "Username is required"); }
  if (empty($password_1)) { array_push($errors, "Password is required"); }

  $user_check_query = "SELECT * FROM users WHERE username='$username' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { 
    if ($user['username'] === $username) {
      array_push($errors, "Username already exists");
    }
  }

  if (count($errors) == 0) {
  	$password = $password_1;

  	$query = "INSERT INTO users (username, passcode) 
  			  VALUES('$username', '$password')";
  	mysqli_query($db, $query);
  	$_SESSION['login_user'] = $username;
  	$_SESSION['success'] = "You are now logged in";
  	header('location: student_interface.php');
  }
}
?>


<!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body bgcolor = "#555555">
 
	<?php include('errors.php'); ?>
  	<div align = "center">
         <div style = "width:780px; border: solid 1px #333333; " align = "left">
            <div style = "background-color:#333333; color:#FFFFFF; padding:3px;"><b>Register</b></div>
				
            <div style = "margin:30px; padding-left:25%; ">
               
               <form action ="register.php" method = "post">
			   <label>Username</label><input type="text" name="username" value="<?php echo $username; ?>"><br /><br />
			   <label>Password</label><input type="password" name="password_1"><br/><br />
			   <button type="submit" class="btn" name="reg_user">Register</button><br />
               </form>
					
            </div>
				
         </div>
			
      </div>


  	<p style="padding-left:50%;">
  		Already a member? <a href="login.php" style="color:coral;">Sign in</a>
  	</p>
  </form>
</body>
</html>