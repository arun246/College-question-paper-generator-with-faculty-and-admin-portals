<html>
    <head>
        <title> Email Marketing</title>
        <style>
        body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: #A8D0E8;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color: white;
  height:600px;
  width:960px;
  border:1px solid dodgerblue;
  border-radius:0.25rem;
}

/* file input fields */
.custom-file-input::-webkit-file-upload-button {
  visibility: hidden;
}
.custom-file-input::before {
  content: 'Select some files';
  display: inline-block;
  background: linear-gradient(top, #f9f9f9, #e3e3e3);
  border: 1px solid #999;
  border-radius: 3px;
  padding: 5px 8px;
  outline: none;
  white-space: nowrap;
  -webkit-user-select: none;
  cursor: pointer;
  text-shadow: 1px 1px #fff;
  font-weight: 700;
  font-size: 10pt;
}
.custom-file-input:hover::before {
  border-color: black;
}
.custom-file-input:active::before {
  background: -webkit-linear-gradient(top, #e3e3e3, #f9f9f9);
}

input[type=reset]{
  width: 25%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #4CAF50;
  color:white;
}

input[type=submit]{
  width: 25%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #4CAF50;
  color:white;
  cursor: pointer;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  border-radius:0.5rem;
  margin: 4px 1000px;
  transition-duration: 0.4s;
  cursor: pointer;
}
.button1 {
  background-color: white; 
  color: black; 
  border: 2px solid #4CAF50;
}

.button1:hover {
  background-color: #4CAF50;
  color: white;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

        </style>

    </head>
<body>
    <?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    $ext="";
    $tmpName="";
    $error="";
    if ( isset($_POST["submit"]) ) {

        if ( isset($_FILES["file"])) {
     
                 //if there was an error uploading the file
             if ($_FILES["file"]["error"] > 0) {
                 echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
     
             }
             else {
                      //Print file details
                 /**  echo "Upload: " . $_FILES["file"]["name"] . "<br />";
                  echo "Type: " . $_FILES["file"]["type"] . "<br />";
                  echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
                  echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";
                **/
                  $tmpName = $_FILES["file"]["tmp_name"];
                  $ext_tmp = explode('.', $_FILES['file']['name']);
                  $ext = strtolower(end($ext_tmp));

                      //file read
                    
                if($ext === 'csv'){
                if(($handle = fopen($tmpName, 'r')) !== FALSE) {
            
                    $row = 0;
            
                    while(($data = fgetcsv($handle, 10000, ';')) !== FALSE) {
                        //neglect first row of csv
                        if($row == 0){ $row++; continue; }
                        // number of fields in the csv
                        $col_count = count($data);
                        // get the values from the csv
                        $con = mysqli_connect('localhost', 'root', '', 'test');
                        if(!$con){
                            die("could not connect to database");

                        }
                        $query = "INSERT INTO reg_user (mail,mob)values('$data[0]','$data[1]')";
                        echo $query;
                        if(!mysqli_query($con, $query)){
                            $error ="details not saved";
                        }
                        // inc the row
                        $row++;
                    }
                    echo $error;
                    fclose($handle);
                    mysqli_close($con);
                    
                }
            }
            else{
                echo"please check if .csv";
            }
             
             }
          } else {
                  echo "No file selected <br />";
          }
     }





?>
    <div class="container">
    <table width="600">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
        <h1>Upload the file and start to Mail</h1>
        <p ><b>First line of csv will be ignored</b></p>
        <hr>
        <p style="color:red;">*file should not exceed 2mb <p>
        <tr>
        <td width="20%">Select file</td>
        <td ><input class="custom-file-input" type="file" name="file"  /></td>
        </tr>
        
        <tr>
        <td>Submit</td>
        <td><input class="button" type="submit" name="submit" value="Upload" /></td>
        </tr>
        <tr>
        <td>Reset</td>
        <td><input class="button" type="reset" name="reset" /></td>
        </tr>
        
        </form>
    </table>
    <button style="margin-left:50%" class="button button1" onclick='window.location.href = "mail.php"'>Start Mailing</button>
     </div>
</body>
</html>