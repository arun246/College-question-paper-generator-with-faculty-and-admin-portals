<html>
<head>
    <title> sending </title>
</head>
<style>
            table{
                font-size:25px;
                border-spacing:1px;
                margin: auto;
                font: bold 19px , Arial;
                }
            thead{
                background-color:rgb(34, 149, 171);
            }
            th{
                padding-left:40px;
                padding-right:40px;
                }
</style>
<body>
<?php

if (!empty($_POST['radio'][1])) { 
    // To ensure that the value is being sent
    // do stuff with $_POST['answer'][1]
    $count=count($_POST['radio']);
    $to = "";
    $subject = "";
    $txt = "";
    $headers = "From: webmaster@example.com" . "\r\n" .
    "CC: somebodyelse@example.com";
    $con=mysqli_connect("localhost","root","","test");
	if (mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
      $sql="SELECT * FROM reg_user";
        $row=0;
        if($result=mysqli_query($con,$sql)){
        $rowcount=mysqli_num_rows($result);
        if($rowcount==$count){
            
            foreach ($_POST['radio'] as $answer) {
                // do stuff with the answer
                    $mail=mysqli_fetch_row($result);
                    //echo $answer;
                    //echo $mail[0];
                    
                    switch (trim($answer)) {
                        case "mail10":
                            $to = trim($mail[0]);
                            $subject = "Hello from ME";
                            $txt = "check this mail10% ";
                            $headers = "From: arun.mbabu911@gmail.com" . "\r\n";
                            $success = mail($to,$subject,$txt,$headers);
                            if (!$success) {
                                $errorMessage = error_get_last()['message'];
                                echo $errorMessage;
                            }
                            break;
                        case "mail20":
                            $to = trim($mail[0]);
                            $subject = "Hello from ME";
                            $txt = "check this mail20% ";
                            $headers = "From: arun.mbabu911@gmail.com" . "\r\n";
                            $success = mail($to,$subject,$txt,$headers);
                            if (!$success) {
                                $errorMessage = error_get_last()['message'];
                                echo $errorMessage;
                            }
                            break;
                        }

            }

        }
    }
    mysqli_free_result($result);
    mysqli_close($con);
    //mail success message
    echo"<table>";
    echo"<thead>";
    echo"<th>";
    echo "sucessfully sent mail";
    echo"</th>";
    echo"</thead>";
    echo"</table>";

}


?>

</body>
</html>