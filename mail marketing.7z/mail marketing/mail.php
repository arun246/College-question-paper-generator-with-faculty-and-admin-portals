<!DOCTYPE html>
    <html>
        <head>
            <title> Mailing List</title>
        </head>
        <style>
            body{
                background-color:#555555;
                font: bold 19px Helvetica, Arial;
                margin-top: 70px;
	        }
            table{
                font-size:25px;
                border-spacing:1px;
                margin: auto;
                font: bold 19px , Arial;
                }
            thead{
                background-color:rgb(34, 149, 171);
            }
            th{
                padding-left:40px;
                padding-right:40px;
                }
            tbody{
                background-color:rgb(132, 132, 132);
                color:white;
            }
            td{
                padding-left:40px;
                padding-right:40px;
                padding-bottom: 20px;
                width:250px;
                font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode';
                padding-top:10px;
                font-size:16px;
                text-shadow: 3px 3px 5px #333333;
            }
            .button{
                background-color:#0875bd;
                color:rgb(25, 0, 255);
                border:none;
                padding:10px 12px;
                margin-top: 30px;
                margin-right: 20px;
                text-align: center;
                border-radius: 6px;
                cursor: pointer;
                display: block;
                width: 100%;
            }
        </style>
        <body>
            <?php
	$con=mysqli_connect("localhost","root","","test");
	if (mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
    echo "<br>";
    echo "<p id='demo'></p>";
    echo "<p id='demo1'></p>";
    echo "<div class='container'>";
    echo"<form action='send.php' method='post'>";
    echo "<table id = 'user_tbl' style='width:60%;border:1px solid black;;border-collapse:collapse;'>";
    echo "<thead>";
	echo "<tr style='border:1px solid black;'>
		<th style='border:1px solid black;' width='30%'>mail</th>
		<th style='border:1px solid black;' width='30%' height='30%'>choose mail-type</th> 
		<th style='border:1px solid black;' width='30%'>send</th>
        </tr>";
    echo "</thead>";
    echo"<tbody>";
        $sql="SELECT * FROM reg_user";
        $row=0;
        if($result=mysqli_query($con,$sql)){
        $rowcount=mysqli_num_rows($result);
        while($r=mysqli_fetch_row($result)){
            echo "<tr style='border:1px solid black;' >";
			echo "<td style='border:1px solid black;' > $r[0] </td>";
            echo "<td style='border:1px solid black;' ><p>mail(a)<input type='radio' checked='checked' name='radio[$row]'  value='mail20'><p>mail(b)<input type='radio' name='radio[$row]'  value='mail50'></p></td>";
            if($row == 0){  
			echo "<td rowspan='$rowcount' style='border:1px solid black;' ><button class='button' type='submit' >Send</button></td>";
            }
            $row++;
            
        }
		
            echo"</tr>";
			mysqli_free_result($result);
        }
        
        echo"</tbody>";
        echo "</table>";
        echo"</form>";
        echo"</div>";
	    //echo $total;
	    mysqli_close($con);
		?>

        </body>
    </html>>